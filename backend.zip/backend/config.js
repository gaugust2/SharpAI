require("dotenv").config();

const OPENAI_API_KEY = "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";

const MONGODB_USER = "root";
const MONGODB_PASSWORD = "bu32ASieWvVnwIsA";

const SPORTS_DATA_API_KEY = "7fa0ecbf9db6436393a42d1256ef41b6";

module.exports = {
  OPENAI_API_KEY,
  MONGODB_USER,
  MONGODB_PASSWORD,
  SPORTS_DATA_API_KEY,
};
